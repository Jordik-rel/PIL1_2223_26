


from django.http import HttpResponse

from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
# Create your views here.


def accueil(request):
    return render(request,"accueil.html")

#condition pour l'inscritpion des utilisateurs

def register(request):
    if request.method == 'POST':
        usertype = request.POST['type_user']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']
        if password==confirm_password:
          if User.objects.filter(username=username).exists():
              messages.info(request,'Cet Email existe dejà')
              return redirect(register)
          else:
              user = User.objects.create_user(username=username,password=password,email=email,usertype=usertype)
              user.set_password(password)
              user.save()
              print("sucess")
              return redirect('login_user')
    else:
        print('This is not post method ')
        return render(request,"inscription.html")
    
def login_user(request):
    if request.method == 'POST':
        email=request.POST[email]
        password=request.POST['password']

        user = auth.authentificate(email=email,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('accueil')
        else:
            messages.info(request,'email ou mot de passe invalid')
            return redirect('login_user')
    else:
       return render(request,"index.html")
    
def logout_user(request):
    auth.logout(request)
    return redirect('accueil')

def dashboard(request):
    return render(request,"admin_dashboard.html")
def faq(request):
    return render(request,"faq.html")
def parametre(request):
    return render(request,"parametre.html")
def profil(request):
    return render(request,"profil.html")