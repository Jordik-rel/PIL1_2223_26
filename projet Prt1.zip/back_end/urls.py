
from django.contrib import admin
from django.urls import path
from .views import accueil,register,login_user,logout_user,dashboard,faq,parametre,profil



urlpatterns = [
    path('', accueil,name="accueil"),
    path('register', register,name="register"),
    path('login_user', login_user, name="login_user"),
    path('logout_user', logout_user, name="logout_user"),
    path('dashboard',dashboard,name="dashboard"),
    path('faq',faq,name="faq"),
    path('parametre',parametre,name="parametre"),
    path('profil',profil,name="profil"),
]
